<?php 
/**
 * Ts_exams Page Controller
 * @category  Controller
 */
class Ts_examsController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "ts_exams";
	}
// No Edit Function Generated Because No Field is Defined as the Primary Key
}
