<?php 
/**
 * Ts_subject Page Controller
 * @category  Controller
 */
class Ts_subjectController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "ts_subject";
	}
// No Edit Function Generated Because No Field is Defined as the Primary Key
}
