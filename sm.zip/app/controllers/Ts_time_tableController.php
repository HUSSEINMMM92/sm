<?php 
/**
 * Ts_time_table Page Controller
 * @category  Controller
 */
class Ts_time_tableController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "ts_time_table";
	}
// No Edit Function Generated Because No Field is Defined as the Primary Key
}
