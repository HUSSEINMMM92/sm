<?php 
/**
 * Ts_exam_result Page Controller
 * @category  Controller
 */
class Ts_exam_resultController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "ts_exam_result";
	}
// No Edit Function Generated Because No Field is Defined as the Primary Key
}
