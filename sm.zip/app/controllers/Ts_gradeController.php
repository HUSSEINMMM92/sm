<?php 
/**
 * Ts_grade Page Controller
 * @category  Controller
 */
class Ts_gradeController extends SecureController{
	function __construct(){
		parent::__construct();
		$this->tablename = "ts_grade";
	}
// No Edit Function Generated Because No Field is Defined as the Primary Key
}
